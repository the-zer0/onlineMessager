document.getElementById('login-form').addEventListener('submit', function (event) {
    event.preventDefault();

    document.getElementById('username-error').style.display = 'none';
    document.getElementById('password-error').style.display = 'none';

    const statusMessage = document.getElementById('status-message');
    statusMessage.style.display = 'none';
    statusMessage.className = 'status-message';

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    let isValid = true;

    if (username === '') {
        document.getElementById('username-error').style.display = 'block';
        isValid = false;
    }

    if (password.length < 6) { 
        document.getElementById('password-error').style.display = 'block';
        isValid = false;
    }

    if (isValid) {
        fetch('php/login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
        })
        .then(response => response.json())
        .then(data => {
            statusMessage.textContent = data.message;
            statusMessage.style.display = 'block';

            if (data.status === 'success') {
                statusMessage.classList.add('success');
                setTimeout(() => {
                    window.location.href = './message.html'; 
                }, 1500);
            } else {
                statusMessage.classList.add('error');
            }
        })
        .catch(error => {
            statusMessage.textContent = 'An error occurred. Please try again.';
            statusMessage.classList.add('error');
            statusMessage.style.display = 'block';
        });
    }
});
