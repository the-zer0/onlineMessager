document.addEventListener("DOMContentLoaded", function () {
    const verifyEmailBtn = document.getElementById("verifyEmail");
    const verifyOtpBtn = document.getElementById("verifyOtp");
    const closeModalBtn = document.getElementById("closeModal");
    const otpModal = document.getElementById("otpModal");
    const otpInput = document.getElementById("otpInput");
    let email = "";

    // Open OTP modal when clicking "Verify"
    verifyEmailBtn.addEventListener("click", function (event) {
        event.preventDefault();
        email = document.getElementById("email").value.trim();

        if (email === "" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            alert("Please enter a valid email address.");
            return;
        }

        fetch("php/send_email_otp.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `email=${encodeURIComponent(email)}`,
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.status === "success") {
                otpModal.style.display = "flex"; // Show modal properly
            }
        })
        .catch(error => console.error("Error:", error));
    });

    // Verify OTP
    verifyOtpBtn.addEventListener("click", function () {
        const otp = otpInput.value.trim();
        if (otp === "") {
            alert("Please enter OTP.");
            return;
        }

        fetch("php/verify_email_otp.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `email=${encodeURIComponent(email)}&otp=${encodeURIComponent(otp)}`,
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.status === "success") {
                otpModal.style.display = "none"; // Close modal on success
            }
        })
        .catch(error => console.error("Error:", error));
    });

    // Close modal
    closeModalBtn.addEventListener("click", function () {
        otpModal.style.display = "none";
    });

    // Close modal when clicking outside the modal-content
    window.addEventListener("click", function (event) {
        if (event.target === otpModal) {
            otpModal.style.display = "none";
        }
    });
});
