<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_email_otp = $_POST['email_otp'];
    $entered_phone_otp = $_POST['phone_otp'];

    if ($entered_email_otp == $_SESSION['email_otp'] && $entered_phone_otp == $_SESSION['phone_otp']) {
        unset($_SESSION['email_otp'], $_SESSION['phone_otp']);
        header("Location: ../message.html");
        exit();
    } else {
        $user_id = $_SESSION['user_id'];
        $sql = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
        unset($_SESSION['user_id']);
        echo "Incorrect OTPs! Your data has been deleted.";
    }
} else {
    header("Location: send_otp.php");
    exit();
}
?>
