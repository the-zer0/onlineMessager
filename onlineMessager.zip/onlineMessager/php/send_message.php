<?php
session_start();
include 'connection.php';
require 'vendor/autoload.php';
use Twilio\Rest\Client;

// Check if message is provided
if (!isset($_GET['message']) || empty(trim($_GET['message']))) {
    echo "Message is required!";
    exit();
}

$message = trim($_GET['message']);

// Twilio credentials
$twilio_sid = 'AC5453b23622f0121f477047762bae8f8c';
$twilio_token = 'c6aaf1097add30dbeaaf787cd10e6a4c';
$twilio_number = '+16813456094';

// Fetch all phone numbers from the participants table
$sql = "SELECT phone_number FROM participants";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $client = new Client($twilio_sid, $twilio_token);

    while ($row = $result->fetch_assoc()) {
        $phone = preg_replace('/\D/', '', $row['phone_number']); 
        $phone = '+91' . $phone; 

        try {
            $client->messages->create(
                $phone,
                [
                    'from' => $twilio_number,
                    'body' => $message
                ]
            );
            echo "Message sent <br>";
        } catch (Exception $e) {
            echo "Error sending to $phone: " . $e->getMessage() . "<br>";
        }
    }
} else {
    echo "No participants found!";
}

$conn->close();
?>
