<?php
session_start();
include 'connection.php';
require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Check if the message is provided
if (!isset($_GET['message']) || empty(trim($_GET['message']))) {
    echo "No message provided!";
    exit();
}

$message = trim($_GET['message']);

// Fetch all emails from the database
$sql = "SELECT email FROM participants";
$result = $conn->query($sql);

if ($result->num_rows === 0) {
    echo "No participants found!";
    exit();
}

// Initialize PHPMailer
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; 
    $mail->SMTPAuth = true;
    $mail->Username = 'manomannem.2346@gmail.com'; 
    $mail->Password = 'koam vrhi vzqd bvit'; // Use an App Password here
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;
    $mail->setFrom('manomannem.2346@gmail.com', 'OnlineMessager');
    
    // Send email to all participants
    while ($row = $result->fetch_assoc()) {
        $email = $row['email'];
        if (!empty($email)) {
            $mail->addAddress($email);
        }
    }

    $mail->Subject = 'Message From Manobharath';
    $mail->Body = $message;
    $mail->send();

    echo "Emails sent successfully!";
} catch (Exception $e) {
    echo "Emails could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

$conn->close();
?>
