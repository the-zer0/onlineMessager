<?php
session_start();
include 'connection.php';
require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Twilio\Rest\Client;

if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details from database
$sql = "SELECT email, phone_number FROM participants WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found!";
    exit();
}

$email = $user['email'];
$phone = preg_replace('/\D/', '', $user['phone_number']); // Remove non-numeric characters
$phone = '+91' . $phone; // Ensure E.164 format (Modify for your country)

$email_otp = rand(100000, 999999);
$phone_otp = rand(100000, 999999);

// Store OTPs in session
$_SESSION['email_otp'] = $email_otp;
$_SESSION['phone_otp'] = $phone_otp;

// Send Email OTP using PHPMailer
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; 
    $mail->SMTPAuth = true;
    $mail->Username = 'manomannem.2346@gmail.com'; 
    $mail->Password = 'koam vrhi vzqd bvit'; // Use an App Password here
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('manomannem.2346@gmail.com', 'OnlineMessager');
    $mail->addAddress($email);
    $mail->Subject = 'Your Email OTP';
    $mail->Body = "Your OTP for email verification is: $email_otp";

    $mail->send();
} catch (Exception $e) {
    echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
    exit();
}

// Send SMS OTP using Twilio
$twilio_sid = 'AC5453b23622f0121f477047762bae8f8c';
$twilio_token = 'c6aaf1097add30dbeaaf787cd10e6a4c';
$twilio_number = '+16813456094';

try {
    $client = new Client($twilio_sid, $twilio_token);
    $client->messages->create(
        $phone,
        [
            'from' => $twilio_number,
            'body' => "Your OTP for phone verification is: $phone_otp"
        ]
    );
} catch (Exception $e) {
    echo "SMS could not be sent. Twilio Error: " . $e->getMessage();
    exit();
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP</title>
</head>
<body>
    <h2>Verify OTP</h2>
    <form action="verify_otp.php" method="POST">
        <label>Email OTP:</label>
        <input type="text" name="email_otp" required>
        <br>
        <label>Phone OTP:</label>
        <input type="text" name="phone_otp" required>
        <br>
        <button type="submit">Verify</button>
    </form>
</body>
</html>
